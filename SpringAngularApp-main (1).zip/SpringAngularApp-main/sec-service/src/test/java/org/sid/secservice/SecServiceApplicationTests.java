package org.sid.secservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
